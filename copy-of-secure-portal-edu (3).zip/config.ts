
// URL Web App Google Apps Script yang telah di-deploy
// Fix: Widened type to string to allow comparisons with placeholder strings in authentication checks
export const GAS_WEB_APP_URL: string = 'https://script.google.com/macros/s/AKfycbzho_vjkDBlckEFA7m7l3FUq65jvojYj1zMvxiTBf85NpHUiIxonu7H23SMiyWBg56phw/exec';
